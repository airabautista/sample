import File from '../util/file.js'

describe('Heroku App', () => {

        it.skip('Heroku App SignUp_TC001', async () => {
            await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
            await $('//button[@id = "signup"]').click();
            await $('//input[@id = "firstName"]').waitForExist();
            await $('//input[@id = "firstName"]').setValue('Aira Marie');
            await $('//input[@id = "lastName"]').setValue('Bautista');
            await $('//input[@id = "email"]').setValue('test_20241024163911@test.com');
            await $('//input[@id = "password"]').setValue('testing');
            await $('//button[@id = "submit"]').click();
            await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
        })
        it('Heroku App Login User_TC002', async () => {
            await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
            await $('//input[@id = "email"]').waitForExist({ timeout: 3000});
            await $('//input[@id = "email"]').setValue('test_20241024163911@test.com');
            await $('//input[@id = "password"]').setValue('testing');
            await $('//button[@id = "submit"]').click();
        })    
        it('Heroku App Add Contact TC003', async () => {
            await $('//button[@id = "add-contact"]').click();
            await $('//input[@id = "firstName"]').waitForExist({ timeout: 3000 });
            await $('//input[@id = "firstName"]').setValue('Baissa');
            await $('//input[@id = "lastName"]').setValue('Atienza');
            await $('//input[@id = "birthdate"]').setValue('2000-07-09');
            await $('//input[@id = "email"]').setValue('atienza@gmail.com');
            await $('//input[@id = "phone"]').setValue('09090606121');
            await $('//input[@id = "street1"]').setValue('Sagrada');
            await $('//input[@id = "street2"]').setValue('Familia');
            await $('//input[@id = "city"]').setValue('Hagonoy');
            await $('//input[@id = "stateProvince"]').setValue('Bulacan');
            await $('//input[@id = "postalCode"]').setValue('3002');
            await $('//input[@id = "country"]').setValue('Philippines');
            await $('//button[@id = "submit"]').click();
            await $('//button[@id = "add-contact"]').click();
            await $('//input[@id = "firstName"]').waitForExist({ timeout: 3000 });
            await $('//input[@id = "firstName"]').setValue('Aldrin');
            await $('//input[@id = "lastName"]').setValue('Atienza');
            await $('//input[@id = "birthdate"]').setValue('2000-07-09');
            await $('//input[@id = "email"]').setValue('atienza@gmail.com');
            await $('//input[@id = "phone"]').setValue('09090606121');
            await $('//input[@id = "street1"]').setValue('Sagrada');
            await $('//input[@id = "street2"]').setValue('Familia');
            await $('//input[@id = "city"]').setValue('Hagonoy');
            await $('//input[@id = "stateProvince"]').setValue('Bulacan');
            await $('//input[@id = "postalCode"]').setValue('3002');
            await $('//input[@id = "country"]').setValue('Philippines');
            await $('//button[@id = "submit"]').click();
            await $('//button[@id = "add-contact"]').click();
            await $('//input[@id = "firstName"]').waitForExist({ timeout: 3000 });
            await $('//input[@id = "firstName"]').setValue('Loisa');
            await $('//input[@id = "lastName"]').setValue('Atienza');
            await $('//input[@id = "birthdate"]').setValue('2000-07-09');
            await $('//input[@id = "email"]').setValue('atienza@gmail.com');
            await $('//input[@id = "phone"]').setValue('09090606121');
            await $('//input[@id = "street1"]').setValue('Sagrada');
            await $('//input[@id = "street2"]').setValue('Familia');
            await $('//input[@id = "city"]').setValue('Hagonoy');
            await $('//input[@id = "stateProvince"]').setValue('Bulacan');
            await $('//input[@id = "postalCode"]').setValue('3002');
            await $('//input[@id = "country"]').setValue('Philippines');
            await $('//button[@id = "submit"]').click();
        })
        it('Heroku App Edit Contact TC004', async () => {
            await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
            await $('//input[@id = "email"]').waitForExist();
            await $('//input[@id = "email"]').setValue('test_20241024163911@test.com');
            await $('//input[@id = "password"]').setValue('testing');
            await $('//button[@id = "submit"]').click();
            await $('/html/body/div/div/table/tr[1]/td[2]').click();
            await $('//button[@id = "edit-contact"]').click();
            await $('//input[@id = "postalCode"]').setValue('');
            await $('//input[@id = "postalCode"]').setValue('20241024');
            await $('//button[@id = "submit"]').click();
            await $('//button[@id = "return"]').click();
        })
        it('Heroku App Delete Contact TC005' , async () => {
            await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
            await $('//input[@id = "email"]').waitForExist({ timeout: 3000});
            await $('//input[@id = "email"]').setValue('test_20241024163911@test.com');
            await $('//input[@id = "password"]').setValue('testing');
            await $('//button[@id = "submit"]').click();
            await $('/html/body/div/div/table/tr[1]/td[2]').click();
            await $('//button[@id = "delete"]').click();
            await browser.acceptAlert();
        })
        it('Heroku App Export Contacts on File_TC006' , async () => {
            await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
            await $('//input[@id = "email"]').waitForExist({ timeout: 3000});
            await $('//input[@id = "email"]').setValue('test_20241024163911@test.com');
            await $('//input[@id = "password"]').setValue('testing');
            await $('//button[@id = "submit"]').click();

            const table = await $(`table`);
            const rows = await table.$$(`tr`);
            const userCount = await rows.length;
            const contactData = {}
            for (let i = 1; i <userCount; i++){
                const cells = await rows[i].$$(`td`);
                const cellCount = cells.length;
                for (let j = 2 ; j < cellCount+1; j++){
                    const header = await $(`//thead//tr//th[${j-1}]`).getText();
                    const data = await $(`//table//tr[${1}]/td[${j}]`).getText();
                    contactData[header] = data;
                }
                await File.appendTxtFile(global.strPathContacts,JSON.stringify(contactData, 0 ,2))
            }

        })
    });
