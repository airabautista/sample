//  class pgUltimateQA{
//     get contactNameEdit(){
//         return $('//input[@id = "et_pb_contact_name_0"]')}
//     get contactMessageEdit(){
//         return $('//textarea[@id = "et_pb_contact_message_0"]')}
//     get submitBtn(){
//         return $('//button[@name = "et_builder_submit_button"]')}
//     get successMsgElm(){
//         return $('//div[@class="et-pb-contact-message"]//p[text()]')}

//     async navigate() {
//         await browser.url('https://ultimateqa.com/filling-out-forms/');
//     }
// }

// export default new pgUltimateQA();